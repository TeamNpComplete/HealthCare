$(document).ready(function() {
    var value  = $('#filter').val();
    console.log(value);
  });